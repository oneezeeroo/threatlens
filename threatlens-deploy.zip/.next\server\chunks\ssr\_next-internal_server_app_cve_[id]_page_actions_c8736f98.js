module.exports=[50782,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cve_%5Bid%5D_page_actions_c8736f98.js.map