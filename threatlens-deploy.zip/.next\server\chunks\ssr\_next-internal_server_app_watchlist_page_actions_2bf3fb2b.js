module.exports=[72671,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_watchlist_page_actions_2bf3fb2b.js.map